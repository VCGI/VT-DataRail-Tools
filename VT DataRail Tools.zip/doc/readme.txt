VT DataRail Tools.pdf is for reading; VT DataRail Tools.docx is its source.
