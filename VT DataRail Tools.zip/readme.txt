VT DataRail Tools
*****************************

This folder contains a toolbox--VT DataRail Tools.tbx, which references scripts by relative paths.

The \scripts\ subfolder contains:
     -scripts that are referenced by VT DataRail Tools.tbx.
     -stand-alone scripts (to be run directly in Python).

     Each script has its own subfolder under \scripts\.

Info on what VT DataRail Tools are and how to use them is in \doc\ subfolder.
